kafkacat -C -b localhost:19092 -t $1 -C
