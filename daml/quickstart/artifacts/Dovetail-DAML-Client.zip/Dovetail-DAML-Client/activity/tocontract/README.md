---
title: Coerce to Contract
weight: 4603
---

This activity is used to coerce a json object to a specific contract json object