---
title: Exercise
weight: 4603
---

This activity is used to invoke a choice of a contract. The list of choices will be available after a contract template is selected.