---
title: Create Contract
weight: 4603
---

This activity is used to create a contract from a daml template. The list of tempates will be available for selection after daml metadata extracted using Dovetail CLi is imported through [Import DAML Metadata Connector](../connector/contract/README.md)