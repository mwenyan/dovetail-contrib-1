---
title: Simple Query
weight: 4603
---

This activity is used to query active contracts on the ledger using Digital Assets json-api query syntax. Query can be parameterized with $variable, and the parameters will be substituded with real values at runtime.