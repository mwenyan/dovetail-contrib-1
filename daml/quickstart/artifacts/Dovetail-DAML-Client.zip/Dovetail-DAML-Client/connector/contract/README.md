---
title: Import DAML Metadata
weight: 4603
---

This connector is used to import daml metadata extracted from Dovetail CLI DAML Parser to create json schemas for templates and choices.
