---
title: Ledger Service Connector
weight: 4603
---

This connector is used to configure settings to connect to a ledger service, at present, only Digital Assets json-api server is supported.